﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Util
    {
        public static IPAddress GetIpAddresses()
        {
            IPAddress result = null;
            String strHostName = Dns.GetHostName();
            
            IPHostEntry iphostentry = Dns.GetHostEntry(strHostName);
            foreach (var item in iphostentry.AddressList)
            {
                if (item.AddressFamily == AddressFamily.InterNetwork)
                {
                    result = item;
                }
            }
            return result;
        }

        public static string GetBufferData(TcpClient tcpClient)
        {
            StringBuilder dataReceived = new StringBuilder();
            if (tcpClient.GetStream().CanRead)
            {
                byte[] myReadBuffer = new byte[1024];
                int numberOfBytesRead = 0;


                do
                {
                    numberOfBytesRead = tcpClient.GetStream().Read(myReadBuffer, 0, myReadBuffer.Length);

                    dataReceived.AppendFormat("{0}", Encoding.ASCII.GetString(myReadBuffer, 0, numberOfBytesRead));

                }
                while (tcpClient.GetStream().DataAvailable);
            }

            return dataReceived.ToString();
        }

        public static string[] SplitRequest(string request)
        {
            return request.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
        }

        public static bool ValidateRequest(string[] request)
        {
            //This will accept HTTP 1.0 or HTTP 1.1 indistinctly to easly allow testing with browser
            if ((request[0] != "GET") ||
                (Uri.IsWellFormedUriString(request[1], UriKind.Relative) == false) /*||
                (request[2] != "HTTP/1.1")*/)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        
        public static void CreateHttpResponse(NetworkStream stream, string httpStatusCode, string httpMessage, string content)
        {
            System.IO.StreamWriter writer = new System.IO.StreamWriter(stream);
            writer.Write("HTTP/1.0 " + httpStatusCode + " " + httpMessage);
            writer.Write(Environment.NewLine);
            writer.Write("Content-Type: text/html; charset=UTF-8");
            writer.Write(Environment.NewLine);
            writer.Write("Content-Length: " + content.Length);
            writer.Write(Environment.NewLine);
            writer.Write(Environment.NewLine);
            writer.WriteLine(content);
            writer.Flush();
        }
        
        public static void CreateHttpResponse(NetworkStream stream, string httpStatusCode, string httpMessage, byte[] content, string mimeType)
        {
                      
            System.IO.StreamWriter writer = new System.IO.StreamWriter(stream);
            writer.Write("HTTP/1.0 " + httpStatusCode + " " + httpMessage);
            writer.Write(Environment.NewLine);
            writer.Write("Content - Type: " + mimeType);
            writer.Write(Environment.NewLine);
            writer.Write("Content-Length: " + content.Length);
            writer.Write(Environment.NewLine);
            writer.Write(Environment.NewLine);
            writer.Flush();

            stream.Write(content, 0, content.Length);
        }        

        public static string GetMimeType(string extension)
        {
            if (extension == null)
            {
                throw new ArgumentNullException("extension");
            }

            if (!extension.StartsWith("."))
            {
                extension = "." + extension;
            }

            string mime;

            return MimeTypeDictionary.mappings.TryGetValue(extension, out mime) ? mime : "application/octet-stream";
        }
    }
}
