﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Threading;

namespace ConsoleApp1
{
    public class HandleConnection
    {
        private readonly TcpClient client;
        private readonly string baseDir;

        public HandleConnection(TcpClient client, string serverBaseDir)
        {
            this.client = client;
            this.baseDir = serverBaseDir;
        }

        public void Start()
        {

            var thread = new Thread(Handle);
            thread.Start();
        }

        private void Handle()
        {
            bool keepAlive = false;
            while (client.Connected)
            {
                try
                {                                        
                    string bufferData = Util.GetBufferData(client);
                    if (bufferData != null)
                    {
                        Console.WriteLine("Received request at: " + DateTime.Now.ToUniversalTime().ToString());
                        Console.WriteLine(bufferData);

                        string[] parsedRequest = Util.SplitRequest(bufferData);
                      
                        string[] parsedHttpRequestLine = parsedRequest[0].Split(' ');

                        if (!Util.ValidateRequest(parsedHttpRequestLine))
                        {                                                
                            Util.CreateHttpResponse(client.GetStream(), "400", "Bad request", "<html><body>Error 400</body></html>");
                        }
                        else
                        {
                            var uriBaseDir = new System.Uri(baseDir, UriKind.Absolute);

                            var formatedPath = parsedHttpRequestLine[1].Substring(1, parsedHttpRequestLine[1].Length - 1).Replace('/', '\\');

                            var uri = new Uri(new Uri(baseDir, UriKind.RelativeOrAbsolute), formatedPath);

                            if (!File.Exists(uri.LocalPath))
                            {
                                Console.WriteLine("");
                                Console.WriteLine("Could not find file {0}", uri.LocalPath.ToString());
                                Console.WriteLine("");
                                Util.CreateHttpResponse(client.GetStream(), "404", "Not found", "<html><body>Error 404</body></html>");
                            }
                            else
                            {
                                Console.WriteLine("Serving " + formatedPath);
                                byte[] data = File.ReadAllBytes(uri.LocalPath);
                                var mimeType = Util.GetMimeType(Path.GetExtension(uri.LocalPath));                                
                                Util.CreateHttpResponse(client.GetStream(), "200", "OK", data, mimeType);
                                Console.WriteLine();
                                Console.WriteLine("Request fulfilled at: " + DateTime.Now.ToUniversalTime().ToString());
                                Console.WriteLine();
                            }
                            
                        }

                        if (!keepAlive)
                        {
                            client.Client.Disconnect(true);
                        }
                    }


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }
    }
}
