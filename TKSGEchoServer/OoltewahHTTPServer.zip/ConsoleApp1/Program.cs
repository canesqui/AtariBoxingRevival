﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpListener server = null;

            string baseDir = (args.Length > 0) ? args[0] : System.AppDomain.CurrentDomain.BaseDirectory;

            int port;

            if (args.Length > 1)
            {
                if (!int.TryParse(args[1], out port))
                    throw new ArgumentException("The port parameter was not provided correctly. The port must be a valid integer value.");
            }
            else
            {
                port = 8888;
            }

            try
            {
                if (!Directory.Exists(baseDir))
                    throw new ArgumentException(String.Format("The base root folder informed does not exist or is inacessible {0}", baseDir));

                var ip = Util.GetIpAddresses();

                IPAddress localAddr = IPAddress.Parse(ip.ToString());

                server = new TcpListener(localAddr, port);

                server.Start();
                Console.WriteLine("Web server initialized");
                Console.WriteLine("Waiting for connections on port {0}", port);
                Console.WriteLine("Server IP address: {0}", ip.ToString());
                Console.WriteLine("Root directory is {0}", baseDir);
                Console.WriteLine();
                Console.WriteLine("You can change these configuration on VS project's properties window on Debug");
                Console.WriteLine("and use {0} {1} as the command line argument field or", "C:\\<your_roor_folder>", "PORT");
                Console.WriteLine("you can use OoltewahHTTPSERVER {0} {1} from the command line.", "C:\\<your_roor_folder>", "PORT");
                Console.WriteLine();

                while (true)
                {

                    TcpClient client = server.AcceptTcpClient();
                    Console.WriteLine("Connected!");                    

                    var connectionThread = new HandleConnection(client, baseDir);

                    connectionThread.Start();
                }
            }
            catch (SocketException e)
            {
                Console.WriteLine("SocketException: {0}", e);
            }
            finally
            {
                server.Stop();
            }
        }
    }
}